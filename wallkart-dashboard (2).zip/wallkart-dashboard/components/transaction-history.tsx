"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowDownToLine, ArrowUpFromLine, ArrowRightLeft, ExternalLink } from "lucide-react"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"

interface Transaction {
  id: string
  type: string
  amount: number
  currency: string
  date: string
  status: string
  description: string
  recipient: string
  fee?: number
  reference?: string
}

interface TransactionHistoryProps {
  showAll?: boolean
  transactions?: Transaction[]
  loading?: boolean
}

// Default transactions if none are provided
const defaultTransactions = [
  {
    id: "TXN001",
    type: "deposit",
    amount: 500.0,
    currency: "USD",
    date: "2024-01-15T10:30:00Z",
    status: "completed",
    description: "Bank transfer deposit",
    recipient: "Your Wallet",
    fee: 0,
    reference: "DEP-2024-001",
  },
  {
    id: "TXN002",
    type: "transfer",
    amount: 150.0,
    currency: "USD",
    date: "2024-01-14T15:45:00Z",
    status: "completed",
    description: "Transfer to John Smith",
    recipient: "john.smith@email.com",
    fee: 2.5,
    reference: "TRF-2024-002",
  },
  {
    id: "TXN003",
    type: "withdraw",
    amount: 200.0,
    currency: "USD",
    date: "2024-01-13T09:15:00Z",
    status: "pending",
    description: "Bank withdrawal",
    recipient: "Bank Account ****1234",
    fee: 5.0,
    reference: "WTH-2024-003",
  },
  {
    id: "TXN004",
    type: "deposit",
    amount: 75,
    currency: "BONUS",
    date: "2024-01-12T14:20:00Z",
    status: "completed",
    description: "Referral bonus",
    recipient: "Your Wallet",
    fee: 0,
    reference: "BON-2024-004",
  },
  {
    id: "TXN005",
    type: "transfer",
    amount: 300.0,
    currency: "EUR",
    date: "2024-01-11T11:30:00Z",
    status: "failed",
    description: "Transfer to Alice Johnson",
    recipient: "alice.johnson@email.com",
    fee: 3.0,
    reference: "TRF-2024-005",
  },
]

export function TransactionHistory({ showAll = false, transactions = [], loading = false }: TransactionHistoryProps) {
  const displayTransactions = transactions.length > 0 ? transactions : defaultTransactions
  const transactionsToShow = showAll ? displayTransactions : displayTransactions.slice(0, 5)

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownToLine className="h-4 w-4 text-green-600" />
      case "withdraw":
        return <ArrowUpFromLine className="h-4 w-4 text-red-600" />
      case "transfer":
        return <ArrowRightLeft className="h-4 w-4 text-blue-600" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge variant="default" className="bg-green-100 text-green-800">
            Completed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            Pending
          </Badge>
        )
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatAmount = (amount: number, currency: string) => {
    switch (currency) {
      case "BONUS":
        return `${amount} coins`
      case "BTC":
        return `₿${amount.toFixed(4)}`
      case "EUR":
        return `€${amount.toFixed(2)}`
      default:
        return `$${amount.toFixed(2)}`
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <Skeleton className="h-6 w-48" />
          {!showAll && <Skeleton className="h-9 w-24" />}
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Recent Transactions</CardTitle>
        {!showAll && (
          <Button variant="outline" size="sm" asChild>
            <Link href="/transactions" className="flex items-center gap-2">
              View All
              <ExternalLink className="h-4 w-4" />
            </Link>
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Status</TableHead>
              {showAll && <TableHead>Reference</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactionsToShow.length > 0 ? (
              transactionsToShow.map((transaction) => {
                const { date, time } = formatDate(transaction.date)
                return (
                  <TableRow key={transaction.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getTypeIcon(transaction.type)}
                        <span className="capitalize font-medium">{transaction.type}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{transaction.description}</div>
                        <div className="text-sm text-gray-500">
                          {transaction.type === "transfer" ? `To: ${transaction.recipient}` : transaction.recipient}
                        </div>
                        {transaction.fee && transaction.fee > 0 && (
                          <div className="text-xs text-gray-400">Fee: ${transaction.fee}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{formatAmount(transaction.amount, transaction.currency)}</div>
                      <div className="text-sm text-gray-500">{transaction.currency}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{date}</div>
                      <div className="text-sm text-gray-500">{time}</div>
                    </TableCell>
                    <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                    {showAll && transaction.reference && (
                      <TableCell>
                        <div className="text-sm font-mono text-gray-600">{transaction.reference}</div>
                      </TableCell>
                    )}
                  </TableRow>
                )
              })
            ) : (
              <TableRow>
                <TableCell colSpan={showAll ? 6 : 5} className="text-center py-8">
                  <div className="text-gray-500">No transactions found</div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
