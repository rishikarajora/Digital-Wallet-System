"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DollarSign, Coins, TrendingUp, Eye, EyeOff, Euro, Bitcoin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface Wallet {
  currency: string
  balance: number
  accountNumber?: string
}

interface WalletCardsProps {
  walletData?: Wallet[]
}

// Default wallet data if none is provided
const defaultWalletData = [
  {
    currency: "USD",
    balance: 2450.75,
    icon: DollarSign,
    color: "bg-blue-500",
    change: "+5.2%",
    changeType: "positive" as const,
    description: "US Dollar Wallet",
  },
  {
    currency: "BONUS",
    balance: 1250,
    icon: Coins,
    color: "bg-yellow-500",
    change: "+12.5%",
    changeType: "positive" as const,
    description: "Reward Points",
  },
  {
    currency: "EUR",
    balance: 890.3,
    icon: Euro,
    color: "bg-green-500",
    change: "-2.1%",
    changeType: "negative" as const,
    description: "Euro Wallet",
  },
  {
    currency: "BTC",
    balance: 0.0234,
    icon: Bitcoin,
    color: "bg-orange-500",
    change: "+8.7%",
    changeType: "positive" as const,
    description: "Bitcoin Wallet",
  },
]

export function WalletCards({ walletData = [] }: WalletCardsProps) {
  const [showBalances, setShowBalances] = useState(true)

  // Map API wallet data to display format
  const displayWallets =
    walletData.length > 0
      ? walletData.map((wallet) => {
          const icon = getWalletIcon(wallet.currency)
          const color = getWalletColor(wallet.currency)
          const change = getRandomChange(wallet.currency)
          return {
            currency: wallet.currency,
            balance: wallet.balance,
            icon,
            color,
            change: change.value,
            changeType: change.type,
            description: getWalletDescription(wallet.currency),
            accountNumber: wallet.accountNumber,
          }
        })
      : defaultWalletData

  const formatBalance = (wallet: any) => {
    if (!showBalances) return "••••••"

    switch (wallet.currency) {
      case "BONUS":
        return `${wallet.balance.toLocaleString()} coins`
      case "BTC":
        return `₿${wallet.balance.toFixed(4)}`
      case "EUR":
        return `€${wallet.balance.toLocaleString()}`
      default:
        return `$${wallet.balance.toLocaleString()}`
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold text-gray-900">Your Wallets</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowBalances(!showBalances)}
          className="flex items-center gap-2"
        >
          {showBalances ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {showBalances ? "Hide" : "Show"} Balances
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {displayWallets.map((wallet, index) => {
          const Icon = wallet.icon
          return (
            <Card key={index} className="relative overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle className="text-sm font-medium text-gray-600">{wallet.currency}</CardTitle>
                  <p className="text-xs text-gray-500">{wallet.description}</p>
                </div>
                <div className={`p-2 rounded-full ${wallet.color}`}>
                  <Icon className="h-4 w-4 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-gray-900">{formatBalance(wallet)}</div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={wallet.changeType === "positive" ? "default" : "destructive"} className="text-xs">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {wallet.change}
                    </Badge>
                    <span className="text-xs text-gray-500">vs last month</span>
                  </div>
                  {wallet.accountNumber && showBalances && (
                    <div className="text-xs text-gray-500 mt-1">Account: {wallet.accountNumber}</div>
                  )}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

// Helper functions
function getWalletIcon(currency: string) {
  switch (currency.toUpperCase()) {
    case "USD":
      return DollarSign
    case "EUR":
      return Euro
    case "BTC":
      return Bitcoin
    case "BONUS":
      return Coins
    default:
      return DollarSign
  }
}

function getWalletColor(currency: string) {
  switch (currency.toUpperCase()) {
    case "USD":
      return "bg-blue-500"
    case "EUR":
      return "bg-green-500"
    case "BTC":
      return "bg-orange-500"
    case "BONUS":
      return "bg-yellow-500"
    default:
      return "bg-gray-500"
  }
}

function getWalletDescription(currency: string) {
  switch (currency.toUpperCase()) {
    case "USD":
      return "US Dollar Wallet"
    case "EUR":
      return "Euro Wallet"
    case "BTC":
      return "Bitcoin Wallet"
    case "BONUS":
      return "Reward Points"
    default:
      return `${currency} Wallet`
  }
}

function getRandomChange(currency: string) {
  // For demo purposes, generate random changes
  const isPositive = Math.random() > 0.3
  const changeValue = (Math.random() * 10).toFixed(1)

  return {
    value: `${isPositive ? "+" : "-"}${changeValue}%`,
    type: isPositive ? "positive" : "negative",
  }
}
