"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowDownToLine, ArrowUpFromLine, ArrowRightLeft } from "lucide-react"

interface ActionButtonsProps {
  onActionClick: (type: "deposit" | "withdraw" | "transfer") => void
}

export function ActionButtons({ onActionClick }: ActionButtonsProps) {
  const actions = [
    {
      type: "deposit" as const,
      label: "Deposit",
      icon: ArrowDownToLine,
      color: "bg-green-500 hover:bg-green-600",
      description: "Add money to your wallet",
    },
    {
      type: "withdraw" as const,
      label: "Withdraw",
      icon: ArrowUpFromLine,
      color: "bg-red-500 hover:bg-red-600",
      description: "Transfer money to your bank",
    },
    {
      type: "transfer" as const,
      label: "Transfer",
      icon: ArrowRightLeft,
      color: "bg-blue-500 hover:bg-blue-600",
      description: "Send money to another user",
    },
  ]

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold text-gray-900">Quick Actions</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {actions.map((action) => {
          const Icon = action.icon
          return (
            <Card key={action.type} className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <Button
                  onClick={() => onActionClick(action.type)}
                  className={`w-full h-auto flex-col space-y-3 py-6 ${action.color} text-white`}
                >
                  <Icon className="h-8 w-8" />
                  <div className="text-center">
                    <div className="font-semibold text-lg">{action.label}</div>
                    <div className="text-sm opacity-90">{action.description}</div>
                  </div>
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
