"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { ArrowDownToLine, ArrowUpFromLine, ArrowRightLeft, Check } from "lucide-react"
import { mockApiRequest } from "@/lib/auth"

interface ActionModalProps {
  isOpen: boolean
  onClose: () => void
  type: "deposit" | "withdraw" | "transfer"
  wallets?: any[]
}

export function ActionModal({ isOpen, onClose, type, wallets = [] }: ActionModalProps) {
  const [amount, setAmount] = useState("")
  const [currency, setCurrency] = useState("USD")
  const [recipient, setRecipient] = useState("")
  const [description, setDescription] = useState("")
  const [bankAccount, setBankAccount] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const { toast } = useToast()

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setAmount("")
      setCurrency("USD")
      setRecipient("")
      setDescription("")
      setBankAccount("")
      setIsSuccess(false)
    }
  }, [isOpen, type])

  const getModalConfig = () => {
    switch (type) {
      case "deposit":
        return {
          title: "Deposit Money",
          description: "Add money to your wallet",
          icon: ArrowDownToLine,
          color: "text-green-600",
        }
      case "withdraw":
        return {
          title: "Withdraw Money",
          description: "Transfer money to your bank account",
          icon: ArrowUpFromLine,
          color: "text-red-600",
        }
      case "transfer":
        return {
          title: "Transfer Money",
          description: "Send money to another user",
          icon: ArrowRightLeft,
          color: "text-blue-600",
        }
    }
  }

  const config = getModalConfig()
  const Icon = config.icon

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Create transaction data
      const transactionData = {
        type,
        amount: Number.parseFloat(amount),
        currency,
        description,
        recipient: type === "transfer" ? recipient : type === "withdraw" ? bankAccount : "Your Wallet",
        fee: type === "withdraw" ? 5 : type === "transfer" ? 2.5 : 0,
      }

      // Call mock API
      await mockApiRequest("/api/transactions", {
        method: "POST",
        body: JSON.stringify(transactionData),
      })

      // Show success state
      setIsSuccess(true)

      // Show toast notification
      toast({
        title: "Transaction Initiated",
        description: `Your ${type} request has been submitted successfully.`,
      })

      // Close modal after delay
      setTimeout(() => {
        onClose()
        setIsSuccess(false)
      }, 2000)
    } catch (error) {
      console.error("Transaction error:", error)
      toast({
        title: "Transaction Failed",
        description: "There was an error processing your request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Available currencies based on user's wallets
  const availableCurrencies =
    wallets.length > 0 ? wallets.map((wallet) => wallet.currency) : ["USD", "EUR", "BTC", "BONUS"]

  // Bank accounts for withdraw
  const bankAccounts = [
    { id: "account1", name: "**** **** **** 1234", bank: "Chase Bank" },
    { id: "account2", name: "**** **** **** 5678", bank: "Bank of America" },
  ]

  // Recent recipients for transfers
  const recentRecipients = [
    { id: "rec1", name: "John Smith", email: "john.smith@example.com" },
    { id: "rec2", name: "Alice Johnson", email: "alice.johnson@example.com" },
    { id: "rec3", name: "Bob Williams", email: "bob.williams@example.com" },
  ]

  if (isSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[425px]">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold text-center mb-2">Transaction Successful!</h2>
            <p className="text-gray-500 text-center mb-6">
              Your {type} request has been submitted and is being processed.
            </p>
            <Button onClick={onClose}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icon className={`h-5 w-5 ${config.color}`} />
            {config.title}
          </DialogTitle>
          <DialogDescription>{config.description}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                min="0"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {availableCurrencies.map((curr) => (
                    <SelectItem key={curr} value={curr}>
                      {curr}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {type === "transfer" && (
            <div className="space-y-2">
              <Label htmlFor="recipient">Recipient</Label>
              <Input
                id="recipient"
                placeholder="Email or username"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                required
              />
              <div className="text-sm text-gray-500">
                <p className="mb-1">Recent recipients:</p>
                <div className="flex flex-wrap gap-1">
                  {recentRecipients.map((rec) => (
                    <Button
                      key={rec.id}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setRecipient(rec.email)}
                      className="text-xs"
                    >
                      {rec.name}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {type === "withdraw" && (
            <div className="space-y-2">
              <Label htmlFor="bankAccount">Bank Account</Label>
              <Select value={bankAccount} onValueChange={setBankAccount}>
                <SelectTrigger>
                  <SelectValue placeholder="Select bank account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} - {account.bank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Add a note..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {/* Transaction fees */}
          <div className="bg-gray-50 p-3 rounded-lg text-sm">
            <div className="flex justify-between">
              <span>Amount:</span>
              <span>{amount ? `${currency} ${amount}` : "-"}</span>
            </div>
            <div className="flex justify-between">
              <span>Fee:</span>
              <span>{type === "withdraw" ? "$5.00" : type === "transfer" ? "$2.50" : "Free"}</span>
            </div>
            <div className="flex justify-between font-semibold border-t pt-2 mt-2">
              <span>Total:</span>
              <span>
                {amount
                  ? `${currency} ${(
                      Number.parseFloat(amount) + (type === "withdraw" ? 5 : type === "transfer" ? 2.5 : 0)
                    ).toFixed(2)}`
                  : "-"}
              </span>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !amount}>
              {isLoading ? "Processing..." : `${config.title.split(" ")[0]} ${amount ? `${currency} ${amount}` : ""}`}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
