"use client"

import { useEffect, useState } from "react"

// Simple authentication service without external dependencies
export class AuthService {
  private static readonly TOKEN_KEY = "wallkart_token"
  private static readonly USER_DATA_KEY = "wallkart_user_data"

  static setToken(token: string): void {
    if (typeof window !== "undefined") {
      localStorage.setItem(this.TOKEN_KEY, token)
    }
  }

  static getToken(): string | null {
    if (typeof window !== "undefined") {
      return localStorage.getItem(this.TOKEN_KEY)
    }
    return null
  }

  static setUserData(userData: any): void {
    if (typeof window !== "undefined") {
      localStorage.setItem(this.USER_DATA_KEY, JSON.stringify(userData))
    }
  }

  static getUserData(): any {
    if (typeof window !== "undefined") {
      const userData = localStorage.getItem(this.USER_DATA_KEY)
      return userData ? JSON.parse(userData) : null
    }
    return null
  }

  static removeToken(): void {
    if (typeof window !== "undefined") {
      localStorage.removeItem(this.TOKEN_KEY)
      localStorage.removeItem(this.USER_DATA_KEY)
    }
  }

  static isAuthenticated(): boolean {
    const token = this.getToken()
    const userData = this.getUserData()
    return !!(token && userData)
  }

  static getUserInfo(): { userId: string; email: string; name: string } | null {
    const userData = this.getUserData()
    return userData
      ? {
          userId: userData.id,
          email: userData.email,
          name: userData.name,
        }
      : null
  }

  static async login(
    email: string,
    password: string,
  ): Promise<{ success: boolean; token?: string; user?: any; error?: string }> {
    try {
      // Demo accounts for immediate testing
      const demoAccounts = [
        { email: "john.doe@example.com", password: "password123", id: "1", name: "John Doe" },
        { email: "jane.smith@example.com", password: "password123", id: "2", name: "Jane Smith" },
        { email: "demo@wallkart.com", password: "demo123", id: "3", name: "Demo User" },
      ]

      const user = demoAccounts.find(
        (account) => account.email.toLowerCase() === email.toLowerCase() && account.password === password,
      )

      if (user) {
        const token = `session_${user.id}_${Date.now()}`

        this.setToken(token)
        this.setUserData({
          id: user.id,
          email: user.email,
          name: user.name,
        })

        return {
          success: true,
          token,
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
          },
        }
      }

      return { success: false, error: "Invalid email or password" }
    } catch (error) {
      console.error("Login error:", error)
      return { success: false, error: "An error occurred during login" }
    }
  }

  static async logout(): Promise<void> {
    this.removeToken()
  }
}

// Mock API data
export const mockData = {
  wallets: {
    "1": [
      { currency: "USD", balance: 2450.75, accountNumber: "****1234" },
      { currency: "EUR", balance: 890.3, accountNumber: "****5678" },
      { currency: "BTC", balance: 0.0234, accountNumber: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa" },
      { currency: "BONUS", balance: 1250, accountNumber: "BONUS001" },
    ],
    "2": [
      { currency: "USD", balance: 1200.5, accountNumber: "****9876" },
      { currency: "BONUS", balance: 500, accountNumber: "BONUS002" },
    ],
    "3": [
      { currency: "USD", balance: 5000.0, accountNumber: "****0000" },
      { currency: "EUR", balance: 2500.0, accountNumber: "****1111" },
      { currency: "BTC", balance: 0.1, accountNumber: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" },
      { currency: "BONUS", balance: 10000, accountNumber: "BONUS000" },
    ],
  },
  transactions: {
    "1": [
      {
        id: "TXN001",
        type: "deposit",
        amount: 500.0,
        currency: "USD",
        date: "2024-01-15T10:30:00Z",
        status: "completed",
        description: "Bank transfer deposit",
        recipient: "Your Wallet",
        fee: 0,
        reference: "DEP-2024-001",
      },
      {
        id: "TXN002",
        type: "transfer",
        amount: 150.0,
        currency: "USD",
        date: "2024-01-14T15:45:00Z",
        status: "completed",
        description: "Transfer to John Smith",
        recipient: "john.smith@email.com",
        fee: 2.5,
        reference: "TRF-2024-002",
      },
      {
        id: "TXN003",
        type: "withdraw",
        amount: 200.0,
        currency: "USD",
        date: "2024-01-13T09:15:00Z",
        status: "pending",
        description: "Bank withdrawal",
        recipient: "Bank Account ****1234",
        fee: 5.0,
        reference: "WTH-2024-003",
      },
    ],
    "2": [
      {
        id: "TXN101",
        type: "deposit",
        amount: 300.0,
        currency: "USD",
        date: "2024-01-12T14:20:00Z",
        status: "completed",
        description: "Initial deposit",
        recipient: "Your Wallet",
        fee: 0,
        reference: "DEP-2024-101",
      },
    ],
    "3": [
      {
        id: "TXN201",
        type: "deposit",
        amount: 1000.0,
        currency: "USD",
        date: "2024-01-10T16:45:00Z",
        status: "completed",
        description: "Demo account funding",
        recipient: "Your Wallet",
        fee: 0,
        reference: "DEMO-2024-201",
      },
      {
        id: "TXN202",
        type: "transfer",
        amount: 250.0,
        currency: "USD",
        date: "2024-01-09T13:20:00Z",
        status: "completed",
        description: "Transfer to Jane Smith",
        recipient: "jane.smith@email.com",
        fee: 0,
        reference: "TRF-2024-202",
      },
    ],
  },
}

// Mock API request function
export async function mockApiRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
  const userData = AuthService.getUserData()

  if (!userData) {
    throw new Error("Unauthorized")
  }

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  const userId = userData.id

  switch (endpoint) {
    case "/api/wallets":
      return {
        success: true,
        data: mockData.wallets[userId as keyof typeof mockData.wallets] || mockData.wallets["3"],
      }
    case "/api/transactions":
      return {
        success: true,
        data: mockData.transactions[userId as keyof typeof mockData.transactions] || mockData.transactions["3"],
        total: (mockData.transactions[userId as keyof typeof mockData.transactions] || mockData.transactions["3"])
          .length,
        hasMore: false,
      }
    default:
      return { success: true, message: "Operation successful" }
  }
}

// React hook for authentication
export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState<{ userId: string; email: string; name: string } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkAuth = () => {
      const authenticated = AuthService.isAuthenticated()
      setIsAuthenticated(authenticated)

      if (authenticated) {
        const userInfo = AuthService.getUserInfo()
        setUser(userInfo)
      } else {
        setUser(null)
      }

      setLoading(false)
    }

    checkAuth()
  }, [])

  const login = async (email: string, password: string) => {
    const result = await AuthService.login(email, password)
    if (result.success && result.user) {
      setIsAuthenticated(true)
      setUser({
        userId: result.user.id,
        email: result.user.email,
        name: result.user.name,
      })
    }
    return result
  }

  const logout = async () => {
    await AuthService.logout()
    setIsAuthenticated(false)
    setUser(null)
  }

  return {
    isAuthenticated,
    user,
    loading,
    login,
    logout,
  }
}
