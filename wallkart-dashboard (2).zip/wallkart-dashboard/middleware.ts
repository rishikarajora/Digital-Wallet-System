import { type NextRequest, NextResponse } from "next/server"

// Protected routes that require authentication
const protectedRoutes = ["/dashboard", "/transactions", "/profile", "/cards"]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Check if the route is protected
  const isProtectedRoute = protectedRoutes.some((route) => pathname.startsWith(route))

  if (isProtectedRoute) {
    // For demo purposes, we'll allow access without strict token validation
    // In a real app, you would validate the session token here
    return NextResponse.next()
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/dashboard/:path*", "/transactions/:path*", "/profile/:path*", "/cards/:path*"],
}
