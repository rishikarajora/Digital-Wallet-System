import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Demo transactions data for different users
const userTransactions = {
  "1": [
    {
      id: "TXN001",
      type: "deposit",
      amount: 500.0,
      currency: "USD",
      date: "2024-01-15T10:30:00Z",
      status: "completed",
      description: "Bank transfer deposit",
      recipient: "Your Wallet",
      fee: 0,
      reference: "DEP-2024-001",
      fromAccount: "Bank Account ****1234",
      toAccount: "Wallkart USD Wallet",
    },
    {
      id: "TXN002",
      type: "transfer",
      amount: 150.0,
      currency: "USD",
      date: "2024-01-14T15:45:00Z",
      status: "completed",
      description: "Transfer to John Smith",
      recipient: "john.smith@email.com",
      fee: 2.5,
      reference: "TRF-2024-002",
      fromAccount: "Wallkart USD Wallet",
      toAccount: "john.smith@email.com",
    },
    {
      id: "TXN003",
      type: "withdraw",
      amount: 200.0,
      currency: "USD",
      date: "2024-01-13T09:15:00Z",
      status: "pending",
      description: "Bank withdrawal",
      recipient: "Bank Account ****1234",
      fee: 5.0,
      reference: "WTH-2024-003",
      fromAccount: "Wallkart USD Wallet",
      toAccount: "Bank Account ****1234",
    },
  ],
  "2": [
    {
      id: "TXN101",
      type: "deposit",
      amount: 300.0,
      currency: "USD",
      date: "2024-01-12T14:20:00Z",
      status: "completed",
      description: "Initial deposit",
      recipient: "Your Wallet",
      fee: 0,
      reference: "DEP-2024-101",
      fromAccount: "Bank Account ****9876",
      toAccount: "Wallkart USD Wallet",
    },
  ],
  "3": [
    {
      id: "TXN201",
      type: "deposit",
      amount: 1000.0,
      currency: "USD",
      date: "2024-01-10T16:45:00Z",
      status: "completed",
      description: "Demo account funding",
      recipient: "Your Wallet",
      fee: 0,
      reference: "DEMO-2024-201",
      fromAccount: "Demo Bank Account",
      toAccount: "Wallkart USD Wallet",
    },
  ],
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, JWT_SECRET) as any

    const transactions = userTransactions[decoded.userId as keyof typeof userTransactions] || []

    // Get query parameters for filtering
    const url = new URL(request.url)
    const type = url.searchParams.get("type")
    const status = url.searchParams.get("status")
    const limit = Number.parseInt(url.searchParams.get("limit") || "10")
    const offset = Number.parseInt(url.searchParams.get("offset") || "0")

    let filteredTransactions = transactions

    if (type && type !== "all") {
      filteredTransactions = filteredTransactions.filter((t) => t.type === type)
    }

    if (status && status !== "all") {
      filteredTransactions = filteredTransactions.filter((t) => t.status === status)
    }

    const paginatedTransactions = filteredTransactions.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: paginatedTransactions,
      total: filteredTransactions.length,
      hasMore: offset + limit < filteredTransactions.length,
    })
  } catch (error) {
    console.error("Transactions fetch error:", error)
    return NextResponse.json({ message: "Invalid token" }, { status: 401 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const transactionData = await request.json()

    // Generate new transaction ID
    const newTransaction = {
      id: `TXN${Date.now()}`,
      ...transactionData,
      date: new Date().toISOString(),
      status: "pending",
      reference: `${transactionData.type.toUpperCase()}-${new Date().getFullYear()}-${Date.now()}`,
    }

    // In a real app, you would save to database here

    return NextResponse.json({
      success: true,
      message: "Transaction created successfully",
      data: newTransaction,
    })
  } catch (error) {
    console.error("Transaction creation error:", error)
    return NextResponse.json({ message: "Transaction failed" }, { status: 500 })
  }
}
