import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(request: NextRequest) {
  try {
    const { refreshToken } = await request.json()

    if (!refreshToken) {
      return NextResponse.json({ message: "Refresh token is required" }, { status: 400 })
    }

    // Verify refresh token
    const decoded = jwt.verify(refreshToken, JWT_SECRET) as any

    // Generate new access token
    const newToken = jwt.sign(
      {
        userId: decoded.userId,
        email: decoded.email,
        name: decoded.name,
      },
      JWT_SECRET,
      { expiresIn: "24h" },
    )

    return NextResponse.json({
      token: newToken,
      message: "Token refreshed successfully",
    })
  } catch (error) {
    return NextResponse.json({ message: "Invalid refresh token" }, { status: 401 })
  }
}
