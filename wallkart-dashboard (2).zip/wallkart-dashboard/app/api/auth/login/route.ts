import { type NextRequest, NextResponse } from "next/server"

// Demo user database - no external dependencies
const users = [
  {
    id: "1",
    email: "john.doe@example.com",
    password: "password123",
    name: "John Doe",
    avatar: "/placeholder.svg?height=40&width=40",
    phone: "+1 (555) 123-4567",
    verified: true,
    kycStatus: "completed",
  },
  {
    id: "2",
    email: "jane.smith@example.com",
    password: "password123",
    name: "Jane Smith",
    avatar: "/placeholder.svg?height=40&width=40",
    phone: "+1 (555) 987-6543",
    verified: true,
    kycStatus: "pending",
  },
  {
    id: "3",
    email: "demo@wallkart.com",
    password: "demo123",
    name: "Demo User",
    avatar: "/placeholder.svg?height=40&width=40",
    phone: "+1 (555) 000-0000",
    verified: true,
    kycStatus: "completed",
  },
]

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ message: "Email and password are required" }, { status: 400 })
    }

    const user = users.find((u) => u.email === email && u.password === password)

    if (!user) {
      return NextResponse.json({ message: "Invalid credentials" }, { status: 401 })
    }

    // Create a simple session token (no JWT library needed)
    const sessionToken = `session_${user.id}_${Date.now()}`

    return NextResponse.json({
      message: "Login successful",
      token: sessionToken,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        phone: user.phone,
        verified: user.verified,
        kycStatus: user.kycStatus,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
