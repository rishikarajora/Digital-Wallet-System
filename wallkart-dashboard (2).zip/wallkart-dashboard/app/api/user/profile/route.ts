import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Demo user profiles with complete data
const userProfiles = {
  "1": {
    id: "1",
    email: "john.doe@example.com",
    name: "John Doe",
    firstName: "John",
    lastName: "Doe",
    phone: "+1 (555) 123-4567",
    avatar: "/placeholder.svg?height=100&width=100",
    address: {
      street: "123 Main Street",
      city: "New York",
      state: "NY",
      zipCode: "10001",
      country: "United States",
    },
    preferences: {
      emailNotifications: true,
      smsNotifications: true,
      transactionAlerts: true,
      marketingEmails: false,
    },
    security: {
      twoFactorEnabled: true,
      lastLogin: "2024-01-15T10:30:00Z",
      loginAttempts: 0,
    },
    verification: {
      emailVerified: true,
      phoneVerified: true,
      kycStatus: "completed",
      kycCompletedAt: "2024-01-01T00:00:00Z",
    },
    wallets: [
      { currency: "USD", balance: 2450.75, accountNumber: "****1234" },
      { currency: "EUR", balance: 890.3, accountNumber: "****5678" },
      { currency: "BTC", balance: 0.0234, accountNumber: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa" },
      { currency: "BONUS", balance: 1250, accountNumber: "BONUS001" },
    ],
    cards: [
      {
        id: "card_1",
        type: "Virtual",
        number: "4532123456789012",
        expiry: "12/26",
        cvv: "123",
        status: "active",
        balance: 2450.75,
      },
      {
        id: "card_2",
        type: "Physical",
        number: "5678901234567890",
        expiry: "08/25",
        cvv: "456",
        status: "active",
        balance: 890.3,
      },
    ],
  },
  "2": {
    id: "2",
    email: "jane.smith@example.com",
    name: "Jane Smith",
    firstName: "Jane",
    lastName: "Smith",
    phone: "+1 (555) 987-6543",
    avatar: "/placeholder.svg?height=100&width=100",
    address: {
      street: "456 Oak Avenue",
      city: "Los Angeles",
      state: "CA",
      zipCode: "90210",
      country: "United States",
    },
    preferences: {
      emailNotifications: true,
      smsNotifications: false,
      transactionAlerts: true,
      marketingEmails: true,
    },
    security: {
      twoFactorEnabled: false,
      lastLogin: "2024-01-14T15:45:00Z",
      loginAttempts: 0,
    },
    verification: {
      emailVerified: true,
      phoneVerified: false,
      kycStatus: "pending",
      kycCompletedAt: null,
    },
    wallets: [
      { currency: "USD", balance: 1200.5, accountNumber: "****9876" },
      { currency: "BONUS", balance: 500, accountNumber: "BONUS002" },
    ],
    cards: [
      {
        id: "card_3",
        type: "Virtual",
        number: "4111111111111111",
        expiry: "06/27",
        cvv: "789",
        status: "active",
        balance: 1200.5,
      },
    ],
  },
  "3": {
    id: "3",
    email: "demo@wallkart.com",
    name: "Demo User",
    firstName: "Demo",
    lastName: "User",
    phone: "+1 (555) 000-0000",
    avatar: "/placeholder.svg?height=100&width=100",
    address: {
      street: "789 Demo Street",
      city: "Demo City",
      state: "DC",
      zipCode: "00000",
      country: "Demo Country",
    },
    preferences: {
      emailNotifications: true,
      smsNotifications: true,
      transactionAlerts: true,
      marketingEmails: false,
    },
    security: {
      twoFactorEnabled: true,
      lastLogin: "2024-01-15T12:00:00Z",
      loginAttempts: 0,
    },
    verification: {
      emailVerified: true,
      phoneVerified: true,
      kycStatus: "completed",
      kycCompletedAt: "2024-01-01T00:00:00Z",
    },
    wallets: [
      { currency: "USD", balance: 5000.0, accountNumber: "****0000" },
      { currency: "EUR", balance: 2500.0, accountNumber: "****1111" },
      { currency: "BTC", balance: 0.1, accountNumber: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh" },
      { currency: "BONUS", balance: 10000, accountNumber: "BONUS000" },
    ],
    cards: [
      {
        id: "card_4",
        type: "Virtual",
        number: "4000000000000002",
        expiry: "12/28",
        cvv: "000",
        status: "active",
        balance: 5000.0,
      },
      {
        id: "card_5",
        type: "Physical",
        number: "5555555555554444",
        expiry: "10/27",
        cvv: "111",
        status: "active",
        balance: 2500.0,
      },
    ],
  },
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, JWT_SECRET) as any

    const userProfile = userProfiles[decoded.userId as keyof typeof userProfiles]
    if (!userProfile) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: userProfile,
    })
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ message: "Invalid token" }, { status: 401 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, JWT_SECRET) as any
    const updates = await request.json()

    // In a real app, you would update the database here
    // For demo purposes, we'll just return success

    return NextResponse.json({
      success: true,
      message: "Profile updated successfully",
      data: updates,
    })
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ message: "Update failed" }, { status: 500 })
  }
}
