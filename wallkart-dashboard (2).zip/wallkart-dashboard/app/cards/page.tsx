"use client"

import { Header } from "@/components/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CreditCard, Plus, MoreVertical, Eye, EyeOff } from "lucide-react"
import { useState } from "react"

export default function Cards() {
  const [showNumbers, setShowNumbers] = useState(false)

  const cards = [
    {
      id: 1,
      type: "Virtual",
      number: "4532 1234 5678 9012",
      expiry: "12/26",
      status: "active",
      balance: 2450.75,
    },
    {
      id: 2,
      type: "Physical",
      number: "5678 9012 3456 7890",
      expiry: "08/25",
      status: "active",
      balance: 890.3,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-gray-900">My Cards</h1>
            <p className="text-gray-600">Manage your virtual and physical cards</p>
          </div>
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add New Card
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {cards.map((card) => (
            <Card key={card.id} className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-700" />
              <CardContent className="relative p-6 text-white">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-6 w-6" />
                    <span className="font-semibold">{card.type} Card</span>
                  </div>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="text-xl font-mono tracking-wider">
                    {showNumbers ? card.number : "**** **** **** " + card.number.slice(-4)}
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm opacity-80">Valid Thru</div>
                      <div className="font-semibold">{card.expiry}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm opacity-80">Balance</div>
                      <div className="font-semibold">${card.balance.toLocaleString()}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex items-center justify-center">
          <Button variant="outline" onClick={() => setShowNumbers(!showNumbers)} className="flex items-center gap-2">
            {showNumbers ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            {showNumbers ? "Hide" : "Show"} Card Numbers
          </Button>
        </div>
      </main>
    </div>
  )
}
