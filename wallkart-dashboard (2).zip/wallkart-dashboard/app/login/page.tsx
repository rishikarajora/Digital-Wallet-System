"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Wallet, Eye, EyeOff, User, Lock } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/hooks/use-toast"

const demoAccounts = [
  {
    email: "john.doe@example.com",
    password: "password123",
    name: "John Doe",
    description: "Main demo account with full access",
  },
  {
    email: "jane.smith@example.com",
    password: "password123",
    name: "Jane Smith",
    description: "Secondary account with pending KYC",
  },
  {
    email: "demo@wallkart.com",
    password: "demo123",
    name: "Demo User",
    description: "Quick demo account for testing",
  },
]

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { login } = useAuth()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const result = await login(email, password)

    if (result.success) {
      toast({
        title: "Login Successful",
        description: "Welcome back to Wallkart!",
      })
      router.push("/dashboard")
    } else {
      toast({
        title: "Login Failed",
        description: result.error || "Invalid credentials",
        variant: "destructive",
      })
    }

    setIsLoading(false)
  }

  const handleDemoLogin = (demoEmail: string, demoPassword: string) => {
    setEmail(demoEmail)
    setPassword(demoPassword)
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Login Form */}
        <Card className="w-full">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="bg-blue-600 text-white p-3 rounded-lg">
                <Wallet className="h-8 w-8" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold">Welcome to Wallkart</CardTitle>
            <CardDescription>Sign in to your digital wallet</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600 mb-2">Forgot your password?</p>
              <Button variant="link" className="text-blue-600">
                Reset Password
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Demo Accounts */}
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="text-xl">Demo Accounts</CardTitle>
            <CardDescription>Try Wallkart with these pre-configured demo accounts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {demoAccounts.map((account, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">{account.name}</h3>
                  <Button variant="outline" size="sm" onClick={() => handleDemoLogin(account.email, account.password)}>
                    Use Account
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mb-2">{account.description}</p>
                <div className="space-y-1 text-xs text-gray-500">
                  <p>
                    <strong>Email:</strong> {account.email}
                  </p>
                  <p>
                    <strong>Password:</strong> {account.password}
                  </p>
                </div>
              </div>
            ))}

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">🔐 Authentication System</h4>
              <div className="text-sm text-blue-800 space-y-1">
                <p>• Simple session-based authentication</p>
                <p>• Secure token storage in localStorage</p>
                <p>• Automatic session management</p>
                <p>• Token key: dev-am5ybn1tb1340jby</p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">💰 Demo Data Includes</h4>
              <div className="text-sm text-green-800 space-y-1">
                <p>• Multiple currency wallets (USD, EUR, BTC, Bonus Coins)</p>
                <p>• Realistic transaction history entries</p>
                <p>• Virtual and physical card data</p>
                <p>• Complete user profile information</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
