"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { WalletCards } from "@/components/wallet-cards"
import { ActionButtons } from "@/components/action-buttons"
import { TransactionHistory } from "@/components/transaction-history"
import { ActionModal } from "@/components/action-modal"
import { useAuth } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { mockApiRequest } from "@/lib/auth"
import { Skeleton } from "@/components/ui/skeleton"

export default function Dashboard() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalType, setModalType] = useState<"deposit" | "withdraw" | "transfer">("deposit")
  const { isAuthenticated, loading } = useAuth()
  const router = useRouter()
  const [userData, setUserData] = useState<any>(null)
  const [walletData, setWalletData] = useState<any[]>([])
  const [transactions, setTransactions] = useState<any[]>([])
  const [dataLoading, setDataLoading] = useState(true)

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push("/login")
    }
  }, [isAuthenticated, loading, router])

  useEffect(() => {
    const fetchData = async () => {
      if (isAuthenticated) {
        try {
          setDataLoading(true)
          // Fetch user profile
          const profileResponse = await mockApiRequest("/api/user/profile")
          setUserData(profileResponse.data)

          // Fetch wallet data
          const walletsResponse = await mockApiRequest("/api/wallets")
          setWalletData(walletsResponse.data)

          // Fetch transactions
          const transactionsResponse = await mockApiRequest("/api/transactions")
          setTransactions(transactionsResponse.data)
        } catch (error) {
          console.error("Error fetching dashboard data:", error)
        } finally {
          setDataLoading(false)
        }
      }
    }

    fetchData()
  }, [isAuthenticated])

  const handleActionClick = (type: "deposit" | "withdraw" | "transfer") => {
    setModalType(type)
    setIsModalOpen(true)
  }

  if (loading || !isAuthenticated) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Welcome back, {userData?.name || "User"}!</p>
        </div>

        {dataLoading ? (
          <div className="space-y-8">
            <div className="space-y-4">
              <Skeleton className="h-8 w-64" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-32 w-full" />
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <Skeleton className="h-8 w-64" />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-40 w-full" />
                ))}
              </div>
            </div>
            <Skeleton className="h-80 w-full" />
          </div>
        ) : (
          <>
            <WalletCards walletData={walletData} />
            <ActionButtons onActionClick={handleActionClick} />
            <TransactionHistory transactions={transactions} />
          </>
        )}
      </main>

      <ActionModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} type={modalType} wallets={walletData} />
    </div>
  )
}
